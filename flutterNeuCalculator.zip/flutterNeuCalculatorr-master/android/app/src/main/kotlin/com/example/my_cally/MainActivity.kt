package com.example.my_cally

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
