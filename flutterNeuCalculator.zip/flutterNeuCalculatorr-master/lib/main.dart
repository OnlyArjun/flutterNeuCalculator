import 'package:flutter/material.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:math_expressions/math_expressions.dart';

bool isDarkMode = false;

void main() {
  runApp(const Cally());
}

class Cally extends StatefulWidget {
  const Cally({Key? key}) : super(key: key);

  @override
  _CallyState createState() => _CallyState();
}

class _CallyState extends State<Cally> {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyCallyScreen(),
    );
  }
}

class MyCallyScreen extends StatefulWidget {
  const MyCallyScreen({Key? key}) : super(key: key);

  @override
  _MyCallyScreenState createState() => _MyCallyScreenState();
}

class _MyCallyScreenState extends State<MyCallyScreen> {
  String expressionToCal = "", resultObtained = "";

  @override
  Widget build(BuildContext context) {
    double systemWidth = MediaQuery.of(context).size.width;
    double systemHeight = MediaQuery.of(context).size.height;

    void expressionParser(String pressedKey) {
      if ((pressedKey == "⌫" && expressionToCal.length == 1) ||
          pressedKey == "AC") {
        setState(() {
          resultObtained = "";
          expressionToCal = "";
        });
        return;
      }

      if (pressedKey == "⌫") {
        setState(() {
          expressionToCal =
              expressionToCal.substring(0, expressionToCal.length - 1);
          resultObtained = "";
        });
      }

      if (expressionToCal.isNotEmpty &&
          (expressionToCal[expressionToCal.length - 1] == '+' ||
              expressionToCal[expressionToCal.length - 1] == '-' ||
              expressionToCal[expressionToCal.length - 1] == '/' ||
              expressionToCal[expressionToCal.length - 1] == 'x' ||
              expressionToCal[expressionToCal.length - 1] == '%') &&
          (pressedKey == '+' ||
              pressedKey == '-' ||
              pressedKey == '/' ||
              pressedKey == 'x' ||
              pressedKey == '%')) {
        setState(() {
          expressionToCal =
              expressionToCal.substring(0, expressionToCal.length - 1) +
                  pressedKey;
        });
        return;
      } else {
        if (pressedKey != "⌫" && pressedKey != "=") {
          setState(() {
            expressionToCal = expressionToCal + pressedKey;
          });
        }

        String expToCal = expressionToCal;
        expToCal = expToCal.replaceAll('x', '*');
        expToCal = expToCal.replaceAll('%', '/100*');
        if (expressionToCal[expressionToCal.length - 1] == '%') {
          expToCal = expToCal.substring(0, expToCal.length - 1);
        }
        Parser p = Parser();
        Expression exp = p.parse(expToCal);

        ContextModel cm = ContextModel();
        double eval = exp.evaluate(EvaluationType.REAL, cm);
        if (eval.isInfinite) {
          setState(() {
            resultObtained = "Cannot Divide by Zero";
          });
        } else {
          if (pressedKey == "=") {
            setState(() {
              expressionToCal = eval.toString();
              resultObtained = "";
            });
            return;
          } else {
            setState(() {
              resultObtained = eval.toString();
            });
          }
        }
      }
    }

    return Scaffold(
      backgroundColor: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    SizedBox(
                      height: systemHeight / 50,
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          isDarkMode = isDarkMode ? false : true;
                        });
                      },
                      child: Container(
                        height: systemHeight / 13,
                        width: systemWidth / 3.2,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            color: isDarkMode
                                ? Colors.grey.shade800
                                : Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(25),
                            boxShadow: [
                              BoxShadow(
                                color: isDarkMode
                                    ? Colors.grey.shade900
                                    : Colors.grey.shade300,
                                offset: const Offset(4.0, 4.0),
                                blurRadius: 10.0,
                                spreadRadius: 1.0,
                              ),
                              BoxShadow(
                                color: isDarkMode
                                    ? Colors.grey.shade700
                                    : Colors.grey.shade100,
                                offset: const Offset(-4.0, -4.0),
                                blurRadius: 10.0,
                                spreadRadius: 1.0,
                              )
                            ]),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Icon(
                              Icons.wb_sunny_rounded,
                              color: isDarkMode
                                  ? Colors.grey.shade200
                                  : Colors.redAccent,
                              size: isDarkMode ? 25 : 35,
                            ),
                            Icon(
                              Icons.nightlight_outlined,
                              color: isDarkMode
                                  ? Colors.redAccent
                                  : Colors.grey.shade500,
                              size: isDarkMode ? 35 : 25,
                            )
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: systemHeight / 8,
                    ),
                    SizedBox(
                      height: 55,
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: AutoSizeText(expressionToCal,
                            maxLines: 1,
                            style: TextStyle(
                                color: isDarkMode == true
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: systemHeight / 16)),
                      ),
                    ),
                    SizedBox(
                      height: systemHeight / 34,
                    ),
                    Align(
                        alignment: Alignment.centerRight,
                        child: Text(resultObtained,
                            style: TextStyle(
                                color: Colors.grey.shade400,
                                fontSize: systemHeight / 30))),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("AC");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "AC",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("⌫");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "⌫",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("%");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "%",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("/");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "/",
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("7");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "7",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("8");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "8",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("9");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "9",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("x");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "x",
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("4");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "4",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("5");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "5",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("6");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "6",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("-");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "-",
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("1");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "1",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("2");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "2",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("3");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "3",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("+");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "+",
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("0");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "0",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("00");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "00",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser(".");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: ".",
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              expressionParser("=");
                            });
                          },
                          child: MyNeuContainers(
                            isDark: isDarkMode,
                            textToDisplay: "=",
                          ),
                        ),
                      ],
                    ),
                  ],
                )
              ]),
        ),
      ),
    );
  }
}

// My Neu StateFul Widget and Containers for all the buttons expcept the mode switcher
// ignore: must_be_immutable
class MyNeuContainers extends StatefulWidget {
  bool isDark;
  String textToDisplay;

  // ignore: use_key_in_widget_constructors
  MyNeuContainers({required this.isDark, required this.textToDisplay});

  @override
  _MyNeuContainersState createState() => _MyNeuContainersState();
}

class _MyNeuContainersState extends State<MyNeuContainers> {
  bool isPressed = false;

  void _pointerDown(PointerDownEvent event) {
    setState(() {
      isPressed = true;
    });
  }

  void _pointerUp(PointerUpEvent event) {
    setState(() {
      isPressed = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    double systemWidth = MediaQuery.of(context).size.width;
    double systemHeight = MediaQuery.of(context).size.height;
    bool isDark = widget.isDark;
    String textToDisplay = widget.textToDisplay;

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Listener(
        onPointerDown: _pointerDown,
        onPointerUp: _pointerUp,
        child: Container(
          height: systemHeight / 12,
          width: systemWidth / 6,
          decoration: BoxDecoration(
              color: isDark ? Colors.grey.shade800 : Colors.grey.shade200,
              borderRadius: BorderRadius.circular(25),
              boxShadow: isPressed
                  ? null
                  : [
                      BoxShadow(
                        color: isDark
                            ? Colors.grey.shade900
                            : Colors.grey.shade300,
                        offset: const Offset(4.0, 4.0),
                        blurRadius: 10.0,
                        spreadRadius: 1.0,
                      ),
                      BoxShadow(
                        color: isDark
                            ? Colors.grey.shade700
                            : Colors.grey.shade100,
                        offset: const Offset(-4.0, -4.0),
                        blurRadius: 10.0,
                        spreadRadius: 1.0,
                      )
                    ]),
          child: Center(
            child: Text(
              textToDisplay,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize:
                      textToDisplay == "AC" || textToDisplay == "⌫" ? 20 : 25,
                  color: textToDisplay == "AC" ||
                          textToDisplay == "⌫" ||
                          textToDisplay == "="
                      ? Colors.red
                      : textToDisplay == "x" ||
                              textToDisplay == "+" ||
                              textToDisplay == "-" ||
                              textToDisplay == "%" ||
                              textToDisplay == "/"
                          ? Colors.lightBlueAccent
                          : isDark
                              ? Colors.white
                              : Colors.black),
            ),
          ),
        ),
      ),
    );
  }
}
